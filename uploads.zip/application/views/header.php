<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Petrotec</title>

  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
  <link href="<?= base_url(); ?>admin_assets/assets/css/animate.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>admin_assets/assets/css/vendor-styles.css" rel="stylesheet">
  <link href="<?= base_url(); ?>admin_assets/assets/css/bootstrap-datepicker.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url(); ?>admin_assets/assets/css/styles.css">
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" />
</head>
<body>
<div class="main-wrapper">